# Android Shop (Java) with Supabase

An Android app (pure Java) with user and admin panels, backed by Supabase (PostgREST + GoTrue). Uses Retrofit/OkHttp for network.

## Requirements
- Android Studio (Giraffe+)
- Android SDK 34
- JDK 17

## Getting started
1. Open this folder in Android Studio (File → Open).
2. In `app/build.gradle`, set your Supabase credentials:
   - Replace `BuildConfig.SUPABASE_URL` and `BuildConfig.SUPABASE_ANON_KEY` empty strings with your values.
3. Sync Gradle and run on a device/emulator.

## Supabase setup (minimal)
- Create a `products` table with columns:
  - `id` (int8, PK, generated), `name` (text), `description` (text), `price` (numeric), `image_url` (text), `stock` (int4), `created_at` (timestamptz default now()).
- Enable RLS and add policies for read/write as needed.

## Modules
- `app/src/main/java/com/example/supashop/ui` → Activities (Main, Login, AdminPanel, UserPanel)
- `app/src/main/java/com/example/supashop/data/supabase` → Retrofit client and API
- `app/src/main/java/com/example/supashop/repository` → Data access layer
- `app/src/main/java/com/example/supashop/models` → Models

## Notes
- Authentication is stubbed; wire login to Supabase GoTrue (email/password or OTP) and call `SupabaseClient.setAuthToken(token)` after sign-in.
- For admin features (create/update/delete), enforce authorization via Supabase RLS.
