package com.example.supashop.data;

import com.example.supashop.models.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductDataManager {
    private static ProductDataManager instance;
    private List<Product> products;
    private int nextId = 1;

    private ProductDataManager() {
        products = new ArrayList<>();
        // Add some sample products
        addSampleProducts();
    }

    public static synchronized ProductDataManager getInstance() {
        if (instance == null) {
            instance = new ProductDataManager();
        }
        return instance;
    }

    private void addSampleProducts() {
        Product p1 = new Product();
        p1.id = nextId++;
        p1.name = "Laptop";
        p1.description = "High performance laptop for work and gaming";
        p1.price = 45000.0;
        p1.stock = 10;
        p1.category = "Electronics";
        p1.imageUrl = "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400";
        products.add(p1);

        Product p2 = new Product();
        p2.id = nextId++;
        p2.name = "Smartphone";
        p2.description = "Latest Android phone with amazing camera";
        p2.price = 25000.0;
        p2.stock = 20;
        p2.category = "Electronics";
        p2.imageUrl = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400";
        products.add(p2);

        Product p3 = new Product();
        p3.id = nextId++;
        p3.name = "Headphones";
        p3.description = "Wireless headphones with noise cancellation";
        p3.price = 3000.0;
        p3.stock = 15;
        p3.category = "Electronics";
        p3.imageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400";
        products.add(p3);

        Product p4 = new Product();
        p4.id = nextId++;
        p4.name = "T-Shirt";
        p4.description = "Cotton casual t-shirt";
        p4.price = 499.0;
        p4.stock = 50;
        p4.category = "Fashion";
        p4.imageUrl = "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400";
        products.add(p4);

        Product p5 = new Product();
        p5.id = nextId++;
        p5.name = "Jeans";
        p5.description = "Denim jeans for men";
        p5.price = 1299.0;
        p5.stock = 30;
        p5.category = "Fashion";
        p5.imageUrl = "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400";
        products.add(p5);

        Product p6 = new Product();
        p6.id = nextId++;
        p6.name = "Coffee Maker";
        p6.description = "Automatic coffee maker";
        p6.price = 2999.0;
        p6.stock = 12;
        p6.category = "Home";
        p6.imageUrl = "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=400";
        products.add(p6);

        // Add more Fashion products
        Product p7 = new Product();
        p7.id = nextId++;
        p7.name = "Sneakers";
        p7.description = "Comfortable sports shoes";
        p7.price = 2499.0;
        p7.stock = 25;
        p7.category = "Fashion";
        p7.imageUrl = "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400";
        products.add(p7);

        Product p8 = new Product();
        p8.id = nextId++;
        p8.name = "Watch";
        p8.description = "Stylish wrist watch";
        p8.price = 1999.0;
        p8.stock = 18;
        p8.category = "Fashion";
        p8.imageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400";
        products.add(p8);

        // Add more Electronics products
        Product p9 = new Product();
        p9.id = nextId++;
        p9.name = "Tablet";
        p9.description = "10-inch display tablet";
        p9.price = 15000.0;
        p9.stock = 8;
        p9.category = "Electronics";
        p9.imageUrl = "https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400";
        products.add(p9);

        Product p10 = new Product();
        p10.id = nextId++;
        p10.name = "Smart Watch";
        p10.description = "Fitness tracking smart watch";
        p10.price = 5999.0;
        p10.stock = 22;
        p10.category = "Electronics";
        p10.imageUrl = "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400";
        products.add(p10);

        // Add more Home products
        Product p11 = new Product();
        p11.id = nextId++;
        p11.name = "Table Lamp";
        p11.description = "LED desk lamp with adjustable brightness";
        p11.price = 899.0;
        p11.stock = 30;
        p11.category = "Home";
        p11.imageUrl = "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400";
        products.add(p11);

        Product p12 = new Product();
        p12.id = nextId++;
        p12.name = "Wall Clock";
        p12.description = "Modern wall clock for home decor";
        p12.price = 699.0;
        p12.stock = 40;
        p12.category = "Home";
        p12.imageUrl = "https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=400";
        products.add(p12);

        Product p13 = new Product();
        p13.id = nextId++;
        p13.name = "Cushion Set";
        p13.description = "Decorative cushion covers set of 4";
        p13.price = 1299.0;
        p13.stock = 35;
        p13.category = "Home";
        p13.imageUrl = "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400";
        products.add(p13);

        // Add Books category
        Product p14 = new Product();
        p14.id = nextId++;
        p14.name = "Programming Book";
        p14.description = "Learn Java programming from basics";
        p14.price = 599.0;
        p14.stock = 20;
        p14.category = "Books";
        p14.imageUrl = "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400";
        products.add(p14);

        Product p15 = new Product();
        p15.id = nextId++;
        p15.name = "Fiction Novel";
        p15.description = "Bestselling fiction novel";
        p15.price = 399.0;
        p15.stock = 45;
        p15.category = "Books";
        p15.imageUrl = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400";
        products.add(p15);

        // Add Sports category
        Product p16 = new Product();
        p16.id = nextId++;
        p16.name = "Yoga Mat";
        p16.description = "Non-slip exercise yoga mat";
        p16.price = 799.0;
        p16.stock = 28;
        p16.category = "Sports";
        p16.imageUrl = "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400";
        products.add(p16);

        Product p17 = new Product();
        p17.id = nextId++;
        p17.name = "Dumbbells";
        p17.description = "Set of 2 dumbbells - 5kg each";
        p17.price = 1499.0;
        p17.stock = 15;
        p17.category = "Sports";
        p17.imageUrl = "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400";
        products.add(p17);

        // Ladies Beauty category (new)
        Product lb1 = new Product();
        lb1.id = nextId++;
        lb1.name = "Lipstick";
        lb1.description = "Matte long-wear lipstick";
        lb1.price = 299.0;
        lb1.stock = 40;
        lb1.category = "Ladies Beauty";
        lb1.imageUrl = "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400";
        products.add(lb1);

        Product lb2 = new Product();
        lb2.id = nextId++;
        lb2.name = "Face Cream";
        lb2.description = "Daily moisturizer SPF 30";
        lb2.price = 549.0;
        lb2.stock = 25;
        lb2.category = "Ladies Beauty";
        lb2.imageUrl = "https://picsum.photos/seed/facecream/600/400";
        products.add(lb2);

        Product lb3 = new Product();
        lb3.id = nextId++;
        lb3.name = "Nail Polish";
        lb3.description = "Quick-dry glossy finish";
        lb3.price = 149.0;
        lb3.stock = 60;
        lb3.category = "Ladies Beauty";
        lb3.imageUrl = "https://picsum.photos/seed/nailpolish/600/400";
        products.add(lb3);
    }

    public List<Product> getAllProducts() {
        return new ArrayList<>(products);
    }

    public List<Product> getProductsByCategory(String category) {
        List<Product> filtered = new ArrayList<>();
        for (Product p : products) {
            if (p.category != null && p.category.equals(category)) {
                filtered.add(p);
            }
        }
        return filtered;
    }

    public List<String> getAllCategories() {
        List<String> categories = new ArrayList<>();
        categories.add("All");
        for (Product p : products) {
            if (p.category != null && !categories.contains(p.category)) {
                categories.add(p.category);
            }
        }
        return categories;
    }

    public Product getProductById(int id) {
        for (Product p : products) {
            if (p.id == id) {
                return p;
            }
        }
        return null;
    }

    public void addProduct(Product product) {
        product.id = nextId++;
        products.add(product);
    }

    public boolean updateProduct(Product updatedProduct) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).id.equals(updatedProduct.id)) {
                products.set(i, updatedProduct);
                return true;
            }
        }
        return false;
    }

    public boolean deleteProduct(int id) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).id == id) {
                products.remove(i);
                return true;
            }
        }
        return false;
    }
}
