package com.example.supashop.ui.admin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supashop.R;
import com.example.supashop.models.CategorySection;

import java.util.ArrayList;
import java.util.List;

public class CategorySectionAdminAdapter extends RecyclerView.Adapter<CategorySectionAdminAdapter.CategoryViewHolder> {
    private List<CategorySection> categorySections = new ArrayList<>();
    private ProductAdminAdapter.OnProductActionListener actionListener;

    public CategorySectionAdminAdapter(ProductAdminAdapter.OnProductActionListener listener) {
        this.actionListener = listener;
    }

    public void setCategorySections(List<CategorySection> sections) {
        this.categorySections = sections;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_section_admin, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        CategorySection section = categorySections.get(position);
        holder.bind(section, actionListener);
    }

    @Override
    public int getItemCount() {
        return categorySections.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategoryName, tvProductCount;
        RecyclerView recyclerProducts;
        ProductAdminAdapter productAdapter;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvProductCount = itemView.findViewById(R.id.tv_product_count);
            recyclerProducts = itemView.findViewById(R.id.recycler_category_products);
        }

        public void bind(CategorySection section, ProductAdminAdapter.OnProductActionListener listener) {
            tvCategoryName.setText(section.categoryName);
            tvProductCount.setText(section.products.size() + " products");
            
            // Setup RecyclerView for products
            productAdapter = new ProductAdminAdapter(listener);
            LinearLayoutManager layoutManager = new LinearLayoutManager(itemView.getContext());
            recyclerProducts.setLayoutManager(layoutManager);
            recyclerProducts.setAdapter(productAdapter);
            recyclerProducts.setNestedScrollingEnabled(false);
            
            productAdapter.setProducts(section.products);
        }
    }
}
