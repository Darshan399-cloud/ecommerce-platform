package com.example.supashop.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.supashop.models.User;
import java.util.ArrayList;
import java.util.List;

public class AuthManager {
    private static AuthManager instance;
    private List<User> users;
    private User currentUser;
    private SharedPreferences prefs;

    private static final String PREFS_NAME = "auth_prefs";
    private static final String KEY_LOGGED_IN = "logged_in";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_ROLE = "role";
    private static final String KEY_FULLNAME = "full_name";

    private AuthManager() {
        users = new ArrayList<>();
        // Default users
        users.add(new User("admin", "admin123", "ADMIN", "Admin User"));
        users.add(new User("user", "user123", "USER", "Regular User"));
    }

    public static synchronized AuthManager getInstance() {
        if (instance == null) {
            instance = new AuthManager();
        }
        return instance;
    }

    // Must be called once (e.g., in Application or first Activity) to enable persistence
    public void initialize(Context context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            loadFromPrefs();
        }
    }

    // Login
    public User login(String username, String password, String role) {
        for (User user : users) {
            if (user.username.equals(username) && 
                user.password.equals(password) && 
                user.role.equals(role)) {
                currentUser = user;
                saveToPrefs(user);
                return user;
            }
        }
        return null;
    }

    // Register
    public boolean register(String username, String password, String role, String fullName) {
        // Check if username already exists
        for (User user : users) {
            if (user.username.equals(username)) {
                return false; // Username already taken
            }
        }
        
        User newUser = new User(username, password, role, fullName);
        users.add(newUser);
        return true;
    }

    // Get current logged-in user
    public User getCurrentUser() {
        return currentUser;
    }

    // Check if user is logged in
    public boolean isLoggedIn() {
        return currentUser != null;
    }

    // Logout
    public void logout() {
        currentUser = null;
        if (prefs != null) {
            prefs.edit().clear().apply();
        }
    }

    // Check if username exists
    public boolean usernameExists(String username) {
        for (User user : users) {
            if (user.username.equals(username)) {
                return true;
            }
        }
        return false;
    }

    private void saveToPrefs(User user) {
        if (prefs == null) return;
        prefs.edit()
                .putBoolean(KEY_LOGGED_IN, true)
                .putString(KEY_USERNAME, user.username)
                .putString(KEY_ROLE, user.role)
                .putString(KEY_FULLNAME, user.fullName)
                .apply();
    }

    private void loadFromPrefs() {
        if (prefs == null) return;
        boolean loggedIn = prefs.getBoolean(KEY_LOGGED_IN, false);
        if (!loggedIn) return;

        String username = prefs.getString(KEY_USERNAME, null);
        String role = prefs.getString(KEY_ROLE, null);
        String fullName = prefs.getString(KEY_FULLNAME, null);

        if (username == null || role == null) return;

        // Try to find the existing seeded user first
        for (User u : users) {
            if (u.username.equals(username) && u.role.equals(role)) {
                currentUser = u;
                return;
            }
        }
        // Else reconstruct a minimal user record (password unknown)
        User restored = new User(username, "", role, fullName != null ? fullName : username);
        currentUser = restored;
    }
}
