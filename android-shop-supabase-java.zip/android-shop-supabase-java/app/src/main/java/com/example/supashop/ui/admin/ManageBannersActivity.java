package com.example.supashop.ui.admin;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.models.Banner;
import com.example.supashop.repository.BannerRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

public class ManageBannersActivity extends AppCompatActivity implements BannerAdminAdapter.OnBannerActionListener {
    private RecyclerView recyclerView;
    private BannerAdminAdapter adapter;
    private BannerRepository repository;
    private FloatingActionButton fabAdd;
    private Uri selectedImageUri;
    private ImageView ivBannerPreview;

    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    if (ivBannerPreview != null) {
                        Glide.with(this)
                                .load(selectedImageUri)
                                .centerCrop()
                                .into(ivBannerPreview);
                    }
                }
            });

    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted) {
                    openImagePicker();
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_banners);

        repository = BannerRepository.getInstance();

        // Setup toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        recyclerView = findViewById(R.id.recycler_banners);
        fabAdd = findViewById(R.id.fab_add_banner);

        setupRecyclerView();
        loadBanners();

        fabAdd.setOnClickListener(v -> showAddEditDialog(null));
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void setupRecyclerView() {
        adapter = new BannerAdminAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void loadBanners() {
        adapter.setBanners(repository.getAllBanners());
    }

    @Override
    public void onEdit(Banner banner) {
        showAddEditDialog(banner);
    }

    @Override
    public void onDelete(Banner banner) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Banner")
                .setMessage("Are you sure you want to delete this banner?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    repository.deleteBanner(banner.id);
                    Toast.makeText(this, "Banner deleted", Toast.LENGTH_SHORT).show();
                    loadBanners();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onToggleStatus(Banner banner) {
        repository.toggleBannerStatus(banner.id);
        Toast.makeText(this, banner.isActive ? "Banner deactivated" : "Banner activated", Toast.LENGTH_SHORT).show();
        loadBanners();
    }

    private void showAddEditDialog(Banner existingBanner) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit_banner, null);

        android.widget.TextView tvTitle = dialogView.findViewById(R.id.tv_dialog_title);
        ivBannerPreview = dialogView.findViewById(R.id.iv_banner_preview);
        Button btnSelectImage = dialogView.findViewById(R.id.btn_select_image);
        TextInputEditText etTitle = dialogView.findViewById(R.id.et_banner_title);
        TextInputEditText etDescription = dialogView.findViewById(R.id.et_banner_description);
        TextInputEditText etImageUrl = dialogView.findViewById(R.id.et_banner_image_url);
        Button btnCancel = dialogView.findViewById(R.id.btn_cancel);
        Button btnSave = dialogView.findViewById(R.id.btn_save);

        selectedImageUri = null;
        boolean isEdit = existingBanner != null;
        tvTitle.setText(isEdit ? "Edit Banner" : "Add Banner");

        if (isEdit) {
            etTitle.setText(existingBanner.title);
            etDescription.setText(existingBanner.description);
            etImageUrl.setText(existingBanner.imageUrl);

            // Load existing image
            if (existingBanner.imageUrl != null && !existingBanner.imageUrl.isEmpty()) {
                Glide.with(this)
                        .load(existingBanner.imageUrl)
                        .centerCrop()
                        .into(ivBannerPreview);
            }
        }

        btnSelectImage.setOnClickListener(v -> checkPermissionAndPickImage());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String imageUrl = etImageUrl.getText().toString().trim();

            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Banner banner = new Banner();
            if (isEdit) {
                banner.id = existingBanner.id;
                banner.isActive = existingBanner.isActive;
                banner.createdAt = existingBanner.createdAt;
            }
            banner.title = title;
            banner.description = description;

            // Use selected image URI or URL
            if (selectedImageUri != null) {
                banner.imageUrl = selectedImageUri.toString();
            } else if (!imageUrl.isEmpty()) {
                banner.imageUrl = imageUrl;
            } else if (isEdit && existingBanner.imageUrl != null) {
                banner.imageUrl = existingBanner.imageUrl;
            } else {
                Toast.makeText(this, "Please select an image or provide URL", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isEdit) {
                repository.updateBanner(banner);
                Toast.makeText(this, "Banner updated", Toast.LENGTH_SHORT).show();
            } else {
                repository.addBanner(banner);
                Toast.makeText(this, "Banner added", Toast.LENGTH_SHORT).show();
            }

            loadBanners();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void checkPermissionAndPickImage() {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        } else {
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            openImagePicker();
        } else {
            permissionLauncher.launch(permission);
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        imagePickerLauncher.launch(intent);
    }
}
