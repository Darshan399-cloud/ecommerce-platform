package com.example.supashop.ui.user;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.models.CartItem;

import java.util.ArrayList;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
    private List<CartItem> cartItems = new ArrayList<>();
    private OnCartChangeListener listener;

    public interface OnCartChangeListener {
        void onQuantityChanged();
        void onItemRemoved();
    }

    public CartAdapter(OnCartChangeListener listener) {
        this.listener = listener;
    }

    public void setCartItems(List<CartItem> items) {
        this.cartItems = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);
        holder.bind(item, listener);
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView ivImage;
        TextView tvName, tvPrice, tvQuantity;
        Button btnDecrease, btnIncrease;
        ImageButton btnRemove;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.cart_item_image);
            tvName = itemView.findViewById(R.id.cart_item_name);
            tvPrice = itemView.findViewById(R.id.cart_item_price);
            tvQuantity = itemView.findViewById(R.id.cart_item_quantity);
            btnDecrease = itemView.findViewById(R.id.btn_decrease);
            btnIncrease = itemView.findViewById(R.id.btn_increase);
            btnRemove = itemView.findViewById(R.id.btn_remove);
        }

        public void bind(CartItem item, OnCartChangeListener listener) {
            tvName.setText(item.productName);
            tvPrice.setText(String.format("₹%.0f", item.price));
            tvQuantity.setText(String.valueOf(item.quantity));

            Glide.with(itemView.getContext())
                    .load(item.productImage)
                    .centerCrop()
                    .placeholder(android.R.color.darker_gray)
                    .into(ivImage);

            btnIncrease.setOnClickListener(v -> {
                item.quantity++;
                tvQuantity.setText(String.valueOf(item.quantity));
                com.example.supashop.repository.CartRepository.getInstance()
                        .updateQuantity(item.productId, item.quantity);
                if (listener != null) listener.onQuantityChanged();
            });

            btnDecrease.setOnClickListener(v -> {
                if (item.quantity > 1) {
                    item.quantity--;
                    tvQuantity.setText(String.valueOf(item.quantity));
                    com.example.supashop.repository.CartRepository.getInstance()
                            .updateQuantity(item.productId, item.quantity);
                    if (listener != null) listener.onQuantityChanged();
                }
            });

            btnRemove.setOnClickListener(v -> {
                com.example.supashop.repository.CartRepository.getInstance()
                        .removeFromCart(item.productId);
                if (listener != null) listener.onItemRemoved();
            });
        }
    }
}
