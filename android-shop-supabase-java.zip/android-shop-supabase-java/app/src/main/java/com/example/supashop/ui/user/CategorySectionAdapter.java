package com.example.supashop.ui.user;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supashop.R;
import com.example.supashop.models.CategorySection;

import java.util.ArrayList;
import java.util.List;

public class CategorySectionAdapter extends RecyclerView.Adapter<CategorySectionAdapter.CategoryViewHolder> {
    private List<CategorySection> categorySections = new ArrayList<>();

    public void setCategorySections(List<CategorySection> sections) {
        this.categorySections = sections;
        android.util.Log.d("CategoryAdapter", "Setting " + sections.size() + " sections");
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_section, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        CategorySection section = categorySections.get(position);
        holder.bind(section);
    }

    @Override
    public int getItemCount() {
        return categorySections.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategoryName, tvSeeAll;
        RecyclerView recyclerProducts;
        ProductUserAdapter productAdapter;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvSeeAll = itemView.findViewById(R.id.tv_see_all);
            recyclerProducts = itemView.findViewById(R.id.recycler_category_products);

            // Setup horizontal RecyclerView for products
            productAdapter = new ProductUserAdapter();
            LinearLayoutManager layoutManager = new LinearLayoutManager(
                    itemView.getContext(),
                    LinearLayoutManager.HORIZONTAL,
                    false
            );
            recyclerProducts.setLayoutManager(layoutManager);
            recyclerProducts.setAdapter(productAdapter);
        }

        public void bind(CategorySection section) {
            android.util.Log.d("CategoryAdapter", "Binding category: " + section.categoryName + " with " + section.products.size() + " products");
            tvCategoryName.setText(section.categoryName);
            productAdapter.setProducts(section.products);
            
            // Show/hide "See all" based on product count
            if (section.products.size() > 3) {
                tvSeeAll.setVisibility(View.VISIBLE);
            } else {
                tvSeeAll.setVisibility(View.GONE);
            }
            
            // Handle "See all" click
            tvSeeAll.setOnClickListener(v -> {
                android.content.Intent intent = new android.content.Intent(itemView.getContext(), CategoryProductsActivity.class);
                intent.putExtra("CATEGORY_NAME", section.categoryName);
                itemView.getContext().startActivity(intent);
            });
        }
    }
}
