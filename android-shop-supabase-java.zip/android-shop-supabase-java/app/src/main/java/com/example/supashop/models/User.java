package com.example.supashop.models;

public class User {
    public String username;
    public String password;
    public String role; // "USER" or "ADMIN"
    public String fullName;
    public String email;

    public User() {
    }

    public User(String username, String password, String role, String fullName) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.fullName = fullName;
        this.email = username; // Use username as email for now
    }

    public boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    public boolean isUser() {
        return "USER".equals(role);
    }
}
