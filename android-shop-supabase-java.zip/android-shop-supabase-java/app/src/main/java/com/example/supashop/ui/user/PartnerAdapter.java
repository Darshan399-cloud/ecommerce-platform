package com.example.supashop.ui.user;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.models.Partner;

import java.util.ArrayList;
import java.util.List;

public class PartnerAdapter extends RecyclerView.Adapter<PartnerAdapter.PartnerViewHolder> {
    private List<Partner> partners = new ArrayList<>();

    public void setPartners(List<Partner> partners) {
        this.partners = partners;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PartnerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_partner_logo, parent, false);
        return new PartnerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PartnerViewHolder holder, int position) {
        Partner partner = partners.get(position);
        holder.bind(partner);
    }

    @Override
    public int getItemCount() {
        return partners.size();
    }

    static class PartnerViewHolder extends RecyclerView.ViewHolder {
        ImageView ivLogo;
        TextView tvName, tvInitials;

        public PartnerViewHolder(@NonNull View itemView) {
            super(itemView);
            ivLogo = itemView.findViewById(R.id.iv_partner_logo);
            tvName = itemView.findViewById(R.id.tv_partner_name);
            tvInitials = itemView.findViewById(R.id.tv_partner_initials);
        }

        public void bind(Partner partner) {
            tvName.setText(partner.name);

            boolean isSvg = partner.logoUrl != null && partner.logoUrl.toLowerCase().endsWith(".svg");
            boolean hasUrl = partner.logoUrl != null && !partner.logoUrl.isEmpty();

            if (hasUrl && !isSvg) {
                tvInitials.setVisibility(View.GONE);
                ivLogo.setVisibility(View.VISIBLE);
                Glide.with(itemView.getContext())
                        .load(partner.logoUrl)
                        .placeholder(R.drawable.ic_placeholder)
                        .error(R.drawable.ic_placeholder)
                        .centerInside()
                        .into(ivLogo);
            } else {
                // Show initials prominently when no renderable image
                ivLogo.setVisibility(View.GONE);
                tvInitials.setVisibility(View.VISIBLE);
                String name = partner.name != null ? partner.name.trim() : "";
                String[] parts = name.split(" ");
                String initials = "";
                if (parts.length >= 2) {
                    initials = (parts[0].isEmpty()?"":parts[0].substring(0,1)) + (parts[1].isEmpty()?"":parts[1].substring(0,1));
                } else if (!name.isEmpty()) {
                    initials = name.substring(0, Math.min(2, name.length()));
                } else {
                    initials = "SS"; // fallback
                }
                tvInitials.setText(initials.toUpperCase());
            }
        }
    }
}
