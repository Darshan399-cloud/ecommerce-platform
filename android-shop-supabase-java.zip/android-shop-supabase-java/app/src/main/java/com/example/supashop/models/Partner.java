package com.example.supashop.models;

public class Partner {
    public String name;
    public String logoUrl;

    public Partner(String name, String logoUrl) {
        this.name = name;
        this.logoUrl = logoUrl;
    }
}
