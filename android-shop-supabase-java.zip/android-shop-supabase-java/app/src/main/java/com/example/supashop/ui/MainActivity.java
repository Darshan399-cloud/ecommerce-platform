package com.example.supashop.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import com.example.supashop.R;
import com.example.supashop.data.AuthManager;
import com.example.supashop.models.User;
import com.example.supashop.ui.admin.AdminPanelActivity;
import com.example.supashop.ui.user.UserPanelActivity;

public class MainActivity extends AppCompatActivity {
    private AuthManager authManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        authManager = AuthManager.getInstance();
        authManager.initialize(getApplicationContext());

        // Check if user is logged in
        if (!authManager.isLoggedIn()) {
            navigateToLogin();
            return;
        }

        User currentUser = authManager.getCurrentUser();
        
        // Redirect based on role
        if (currentUser.isAdmin()) {
            navigateToAdminPanel();
        } else {
            navigateToUserPanel();
        }
    }

    private void navigateToLogin() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void navigateToUserPanel() {
        Intent intent = new Intent(MainActivity.this, UserPanelActivity.class);
        startActivity(intent);
        finish();
    }

    private void navigateToAdminPanel() {
        Intent intent = new Intent(MainActivity.this, AdminPanelActivity.class);
        startActivity(intent);
        finish();
    }
}
