package com.example.supashop.repository;

import com.example.supashop.models.Order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class OrderRepository {
    private static OrderRepository instance;
    private Map<String, Order> orders;

    private OrderRepository() {
        orders = new HashMap<>();
    }

    public static synchronized OrderRepository getInstance() {
        if (instance == null) {
            instance = new OrderRepository();
        }
        return instance;
    }

    public String createOrder(Order order) {
        if (order.id == null || order.id.isEmpty()) {
            order.id = UUID.randomUUID().toString();
        }
        orders.put(order.id, order);
        return order.id;
    }

    public List<Order> getAllOrders() {
        return new ArrayList<>(orders.values());
    }

    public List<Order> getOrdersByUserId(String userId) {
        List<Order> userOrders = new ArrayList<>();
        for (Order order : orders.values()) {
            if (order.userId.equals(userId)) {
                userOrders.add(order);
            }
        }
        return userOrders;
    }

    public Order getOrderById(String orderId) {
        return orders.get(orderId);
    }

    public void updateOrderStatus(String orderId, String status) {
        Order order = orders.get(orderId);
        if (order != null) {
            order.status = status;
        }
    }

    public void deleteOrder(String orderId) {
        orders.remove(orderId);
    }
}
