package com.example.supashop.ui.user;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.models.Product;
import com.example.supashop.repository.CartRepository;

import java.util.ArrayList;
import java.util.List;

public class ProductUserAdapter extends RecyclerView.Adapter<ProductUserAdapter.ProductViewHolder> {
    private List<Product> products = new ArrayList<>();
    private OnCartUpdateListener cartUpdateListener;

    public interface OnCartUpdateListener {
        void onCartUpdated();
    }

    public void setCartUpdateListener(OnCartUpdateListener listener) {
        this.cartUpdateListener = listener;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product_user_enhanced, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = products.get(position);
        holder.bind(product, cartUpdateListener);
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProductImage;
        TextView tvName, tvDescription, tvPrice, tvStock, tvCategory;
        Button btnAddToCart;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProductImage = itemView.findViewById(R.id.iv_product_image);
            tvName = itemView.findViewById(R.id.tv_product_name);
            tvCategory = itemView.findViewById(R.id.tv_product_category);
            tvDescription = itemView.findViewById(R.id.tv_product_description);
            tvPrice = itemView.findViewById(R.id.tv_product_price);
            tvStock = itemView.findViewById(R.id.tv_product_stock);
            btnAddToCart = itemView.findViewById(R.id.btn_add_to_cart);
        }

        public void bind(Product product, OnCartUpdateListener listener) {
            if (tvName != null) tvName.setText(product.name);
            if (tvCategory != null) tvCategory.setText(product.category != null ? product.category : "General");
            if (tvDescription != null) tvDescription.setText(product.description);
            if (tvPrice != null) tvPrice.setText(String.format("%.0f", product.price));
            
            // Load image with Glide
            if (ivProductImage != null) {
                if (product.imageUrl != null && !product.imageUrl.isEmpty()) {
                    Glide.with(itemView.getContext())
                            .load(product.imageUrl)
                            .placeholder(R.drawable.ic_placeholder)
                            .error(R.drawable.ic_placeholder)
                            .centerCrop()
                            .into(ivProductImage);
                } else {
                    ivProductImage.setImageResource(R.drawable.ic_placeholder);
                }
            }
            
            if (tvStock != null) {
                if (product.stock > 0) {
                    tvStock.setText("In Stock");
                    tvStock.setTextColor(0xFF007600);
                } else {
                    tvStock.setText("Out of Stock");
                    tvStock.setTextColor(0xFFB12704);
                }
            }
            
            if (btnAddToCart != null) {
                if (product.stock > 0) {
                    btnAddToCart.setEnabled(true);
                    btnAddToCart.setAlpha(1.0f);
                } else {
                    btnAddToCart.setEnabled(false);
                    btnAddToCart.setAlpha(0.5f);
                }
                
                // Add to cart button click
                btnAddToCart.setOnClickListener(v -> {
                    if (product.stock > 0) {
                        CartRepository.getInstance().addToCart(product, 1);
                        Toast.makeText(itemView.getContext(), product.name + " added to cart", Toast.LENGTH_SHORT).show();
                        if (listener != null) {
                            listener.onCartUpdated();
                        }
                    }
                });
            }
        }
    }
}
