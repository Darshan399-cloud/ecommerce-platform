package com.example.supashop.models;

public class CartItem {
    public Integer productId;
    public String productName;
    public String productImage;
    public double price;
    public int quantity;

    public CartItem() {}

    public CartItem(Product product, int quantity) {
        this.productId = product.id;
        this.productName = product.name;
        this.productImage = product.imageUrl;
        this.price = product.price;
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return price * quantity;
    }
}
