package com.example.supashop.repository;

import com.example.supashop.models.CartItem;
import com.example.supashop.models.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartRepository {
    private static CartRepository instance;
    private Map<Integer, CartItem> cartItems; // productId -> CartItem

    private CartRepository() {
        cartItems = new HashMap<>();
    }

    public static synchronized CartRepository getInstance() {
        if (instance == null) {
            instance = new CartRepository();
        }
        return instance;
    }

    public void addToCart(Product product, int quantity) {
        if (cartItems.containsKey(product.id)) {
            CartItem item = cartItems.get(product.id);
            item.quantity += quantity;
        } else {
            cartItems.put(product.id, new CartItem(product, quantity));
        }
    }

    public void updateQuantity(Integer productId, int quantity) {
        if (quantity <= 0) {
            cartItems.remove(productId);
        } else if (cartItems.containsKey(productId)) {
            cartItems.get(productId).quantity = quantity;
        }
    }

    public void removeFromCart(Integer productId) {
        cartItems.remove(productId);
    }

    public List<CartItem> getCartItems() {
        return new ArrayList<>(cartItems.values());
    }

    public int getCartCount() {
        return cartItems.size();
    }

    public double getTotalAmount() {
        double total = 0;
        for (CartItem item : cartItems.values()) {
            total += item.getTotalPrice();
        }
        return total;
    }

    public void clearCart() {
        cartItems.clear();
    }

    public boolean isEmpty() {
        return cartItems.isEmpty();
    }
}
