package com.example.supashop.ui.admin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.models.Banner;

import java.util.ArrayList;
import java.util.List;

public class BannerAdminAdapter extends RecyclerView.Adapter<BannerAdminAdapter.BannerViewHolder> {
    private List<Banner> banners = new ArrayList<>();
    private OnBannerActionListener listener;

    public interface OnBannerActionListener {
        void onEdit(Banner banner);
        void onDelete(Banner banner);
        void onToggleStatus(Banner banner);
    }

    public BannerAdminAdapter(OnBannerActionListener listener) {
        this.listener = listener;
    }

    public void setBanners(List<Banner> banners) {
        this.banners = banners;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BannerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_banner_admin, parent, false);
        return new BannerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BannerViewHolder holder, int position) {
        Banner banner = banners.get(position);
        holder.bind(banner, listener);
    }

    @Override
    public int getItemCount() {
        return banners.size();
    }

    static class BannerViewHolder extends RecyclerView.ViewHolder {
        private ImageView bannerImage;
        private TextView bannerTitle;
        private TextView bannerDescription;
        private TextView bannerStatus;
        private ImageButton btnEdit;
        private ImageButton btnToggle;
        private ImageButton btnDelete;

        public BannerViewHolder(@NonNull View itemView) {
            super(itemView);
            bannerImage = itemView.findViewById(R.id.banner_image);
            bannerTitle = itemView.findViewById(R.id.banner_title);
            bannerDescription = itemView.findViewById(R.id.banner_description);
            bannerStatus = itemView.findViewById(R.id.banner_status);
            btnEdit = itemView.findViewById(R.id.btn_edit);
            btnToggle = itemView.findViewById(R.id.btn_toggle);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }

        public void bind(Banner banner, OnBannerActionListener listener) {
            bannerTitle.setText(banner.title);
            bannerDescription.setText(banner.description);
            
            if (banner.isActive) {
                bannerStatus.setText("Active");
                bannerStatus.setTextColor(0xFF4CAF50);
            } else {
                bannerStatus.setText("Inactive");
                bannerStatus.setTextColor(0xFFF44336);
            }
            
            Glide.with(itemView.getContext())
                    .load(banner.imageUrl)
                    .centerCrop()
                    .placeholder(android.R.color.darker_gray)
                    .into(bannerImage);

            btnEdit.setOnClickListener(v -> listener.onEdit(banner));
            btnToggle.setOnClickListener(v -> listener.onToggleStatus(banner));
            btnDelete.setOnClickListener(v -> listener.onDelete(banner));
        }
    }
}
