package com.example.supashop.models;

public class Banner {
    public String id;
    public String imageUrl;
    public String title;
    public String description;
    public boolean isActive;
    public long createdAt;

    public Banner() {
        this.createdAt = System.currentTimeMillis();
        this.isActive = true;
    }

    public Banner(String id, String imageUrl, String title, String description) {
        this.id = id;
        this.imageUrl = imageUrl;
        this.title = title;
        this.description = description;
        this.isActive = true;
        this.createdAt = System.currentTimeMillis();
    }
}
