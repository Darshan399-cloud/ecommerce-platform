package com.example.supashop.models;

import java.util.List;

public class CategorySection {
    public String categoryName;
    public List<Product> products;

    public CategorySection(String categoryName, List<Product> products) {
        this.categoryName = categoryName;
        this.products = products;
    }
}
