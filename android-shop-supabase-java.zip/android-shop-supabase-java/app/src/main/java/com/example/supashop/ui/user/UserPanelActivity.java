package com.example.supashop.ui.user;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.supashop.R;
import com.example.supashop.data.AuthManager;
import com.example.supashop.models.Banner;
import com.example.supashop.models.CategorySection;
import com.example.supashop.models.Partner;
import com.example.supashop.models.Product;
import com.example.supashop.repository.BannerRepository;
import com.example.supashop.repository.ProductRepository;
import com.example.supashop.ui.LoginActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserPanelActivity extends AppCompatActivity {
    private RecyclerView recyclerCategorySections;
    private CategorySectionAdapter categorySectionAdapter;
    private ProductRepository repository;
    private AuthManager authManager;
    private EditText etSearch;
    private TextView tvWelcome;
    private ChipGroup chipGroupCategories;
    private List<Product> allProducts;
    private String selectedCategory = "All";
    
    // Banner slider
    private ViewPager2 bannerViewPager;
    private BannerAdapter bannerAdapter;
    private BannerRepository bannerRepository;
    private Handler sliderHandler;
    private Runnable sliderRunnable;
    
    // Partners
    private RecyclerView recyclerPartners;
    private PartnerAdapter partnerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_panel);

        authManager = AuthManager.getInstance();
        repository = new ProductRepository();
        bannerRepository = BannerRepository.getInstance();
        
        // Setup toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        recyclerCategorySections = findViewById(R.id.recycler_category_sections);
        etSearch = findViewById(R.id.et_search);
        tvWelcome = findViewById(R.id.tv_welcome);
        bannerViewPager = findViewById(R.id.banner_viewpager);
        
        // Set welcome message
        if (authManager.getCurrentUser() != null) {
            tvWelcome.setText("Hello, " + authManager.getCurrentUser().fullName);
        }
        setupBannerSlider();
        chipGroupCategories = findViewById(R.id.chip_group_categories);
        recyclerPartners = findViewById(R.id.recycler_partners);
        setupRecyclerView();
        setupPartners();
        setupCategoryChips();
        setupSearch();
        loadProducts();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_user, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            handleLogout();
            return true;
        } else if (item.getItemId() == R.id.action_cart) {
            openCart();
            return true;
        } else if (item.getItemId() == R.id.action_ai) {
            showAIDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openCart() {
        Intent intent = new Intent(UserPanelActivity.this, CartActivity.class);
        startActivity(intent);
    }

    private void handleLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    authManager.logout();
                    Intent intent = new Intent(UserPanelActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void setupBannerSlider() {
        bannerAdapter = new BannerAdapter();
        bannerViewPager.setAdapter(bannerAdapter);
        
        // Load banners
        List<Banner> banners = bannerRepository.getActiveBanners();
        bannerAdapter.setBanners(banners);
        
        // Setup auto-slide
        sliderHandler = new Handler(Looper.getMainLooper());
        sliderRunnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = bannerViewPager.getCurrentItem();
                int totalItems = bannerAdapter.getItemCount();
                
                if (totalItems > 0) {
                    int nextItem = (currentItem + 1) % totalItems;
                    bannerViewPager.setCurrentItem(nextItem, true);
                }
                
                sliderHandler.postDelayed(this, 3000); // Auto-slide every 3 seconds
            }
        };
        
        // Start auto-slide
        sliderHandler.postDelayed(sliderRunnable, 3000);
    }

    private void setupRecyclerView() {
        categorySectionAdapter = new CategorySectionAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerCategorySections.setLayoutManager(layoutManager);
        recyclerCategorySections.setAdapter(categorySectionAdapter);
        recyclerCategorySections.setNestedScrollingEnabled(false);
    }
    
    private void setupPartners() {
        partnerAdapter = new PartnerAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerPartners.setLayoutManager(layoutManager);
        recyclerPartners.setAdapter(partnerAdapter);
        
        // Add partner logos (PNG endpoints)
        List<Partner> partners = new ArrayList<>();
        partners.add(new Partner("Amazon", "https://logo.clearbit.com/amazon.com"));
        partners.add(new Partner("Flipkart", "https://logo.clearbit.com/flipkart.com"));
        partners.add(new Partner("Myntra", "https://logo.clearbit.com/myntra.com"));
        partners.add(new Partner("Ajio", "https://logo.clearbit.com/ajio.com"));
        partners.add(new Partner("Meesho", "https://logo.clearbit.com/meesho.com"));
        partners.add(new Partner("Snapdeal", "https://logo.clearbit.com/snapdeal.com"));
        partners.add(new Partner("Tata", "https://logo.clearbit.com/tata.com"));
        partners.add(new Partner("Reliance", "https://logo.clearbit.com/reliance.com"));
        
        partnerAdapter.setPartners(partners);
    }

    private void setupCategoryChips() {
        chipGroupCategories = findViewById(R.id.chip_group_categories);
        List<String> categories = com.example.supashop.data.ProductDataManager.getInstance().getAllCategories();
        
        android.util.Log.d("UserPanel", "Setting up " + categories.size() + " category chips");
        
        for (String category : categories) {
            Chip chip = new Chip(this);
            chip.setText(category);
            chip.setCheckable(true);
            chip.setChipBackgroundColorResource(android.R.color.white);
            chip.setTextColor(getResources().getColor(android.R.color.black));
            
            if (category.equals("All")) {
                chip.setChecked(true);
                selectedCategory = "All"; // Set default
                android.util.Log.d("UserPanel", "All chip selected by default");
            }
            
            chip.setOnClickListener(v -> {
                android.util.Log.d("UserPanel", "Chip clicked: " + category);
                selectedCategory = category;
                filterByCategory(category);
            });
            
            chipGroupCategories.addView(chip);
        }
    }

    private void loadProducts() {
        allProducts = repository.listProducts();
        loadCategorySections();
    }

    // Build sections but optionally place an AI suggestions section at the top
    private void loadCategorySectionsWithAISuggestions(List<Product> aiSuggestions) {
        if ((allProducts == null || allProducts.isEmpty()) && (aiSuggestions == null || aiSuggestions.isEmpty())) {
            android.util.Log.d("UserPanel", "No products found!");
            return;
        }

        Map<String, List<Product>> categoryMap = new HashMap<>();
        if (allProducts != null) {
            for (Product product : allProducts) {
                String category = product.category != null ? product.category : "General";
                if (!categoryMap.containsKey(category)) categoryMap.put(category, new ArrayList<>());
                categoryMap.get(category).add(product);
            }
        }

        List<CategorySection> sections = new ArrayList<>();
        if (aiSuggestions != null && !aiSuggestions.isEmpty()) {
            sections.add(new CategorySection("AI Suggestions", aiSuggestions));
        }

        // Always place Ladies Beauty first if available
        if (categoryMap.containsKey("Ladies Beauty") && !categoryMap.get("Ladies Beauty").isEmpty()) {
            sections.add(new CategorySection("Ladies Beauty", categoryMap.get("Ladies Beauty")));
            categoryMap.remove("Ladies Beauty");
        }
        for (Map.Entry<String, List<Product>> entry : categoryMap.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                sections.add(new CategorySection(entry.getKey(), entry.getValue()));
            }
        }

        categorySectionAdapter.setCategorySections(sections);
    }
    
    private void loadCategorySections() {
        if (allProducts == null || allProducts.isEmpty()) {
            android.util.Log.d("UserPanel", "No products found!");
            return;
        }
        
        // Group products by category
        Map<String, List<Product>> categoryMap = new HashMap<>();
        
        for (Product product : allProducts) {
            String category = product.category != null ? product.category : "General";
            if (!categoryMap.containsKey(category)) {
                categoryMap.put(category, new ArrayList<>());
            }
            categoryMap.get(category).add(product);
        }
        
        android.util.Log.d("UserPanel", "Total categories: " + categoryMap.size());
        
        // Create category sections
        List<CategorySection> sections = new ArrayList<>();
        // Place Ladies Beauty first if exists
        if (categoryMap.containsKey("Ladies Beauty") && !categoryMap.get("Ladies Beauty").isEmpty()) {
            sections.add(new CategorySection("Ladies Beauty", categoryMap.get("Ladies Beauty")));
            android.util.Log.d("UserPanel", "Category: Ladies Beauty, Products: " + categoryMap.get("Ladies Beauty").size());
            categoryMap.remove("Ladies Beauty");
        }
        for (Map.Entry<String, List<Product>> entry : categoryMap.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                sections.add(new CategorySection(entry.getKey(), entry.getValue()));
                android.util.Log.d("UserPanel", "Category: " + entry.getKey() + ", Products: " + entry.getValue().size());
            }
        }
        
        android.util.Log.d("UserPanel", "Total sections: " + sections.size());
        categorySectionAdapter.setCategorySections(sections);
    }

    private void filterByCategory(String category) {
        if (category.equals("All")) {
            loadCategorySections();
        } else {
            List<Product> filtered = com.example.supashop.data.ProductDataManager.getInstance().getProductsByCategory(category);
            List<CategorySection> sections = new ArrayList<>();
            if (!filtered.isEmpty()) {
                sections.add(new CategorySection(category, filtered));
            }
            categorySectionAdapter.setCategorySections(sections);
        }
    }

    // Prompt user for AI query
    private void showAIDialog() {
        final EditText input = new EditText(this);
        input.setHint("E.g. cheap fashion under 500, best electronics, red shoes");
        new AlertDialog.Builder(this)
                .setTitle("Ask AI for suggestions")
                .setView(input)
                .setPositiveButton("Suggest", (d, w) -> {
                    String q = input.getText().toString();
                    List<Product> ai = aiSuggestProducts(q);
                    loadCategorySectionsWithAISuggestions(ai);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Very lightweight NLP to map query -> products
    private List<Product> aiSuggestProducts(String query) {
        List<Product> results = new ArrayList<>();
        if (allProducts == null || allProducts.isEmpty()) return results;

        if (query == null) query = "";
        String q = query.toLowerCase(Locale.ROOT);

        // Price intent
        Double maxPrice = null;
        Matcher m = Pattern.compile("(under|below|<=|less than)\\s*(\\d+)").matcher(q);
        if (m.find()) {
            try { maxPrice = Double.parseDouble(m.group(2)); } catch (Exception ignored) {}
        }
        if (q.contains("cheap") || q.contains("budget")) {
            if (maxPrice == null) maxPrice = 500.0;
        }
        if (q.contains("premium") || q.contains("expensive")) {
            // prefer higher priced
            // We'll sort later by price desc (not needed if few)
        }

        // Category intent
        String desiredCategory = null;
        String[] known = new String[]{"electronics","fashion","home","books","sports","general"};
        for (String c : known) {
            if (q.contains(c)) { desiredCategory = capitalize(c); break; }
        }

        // Keyword search by name/description
        String keyword = null;
        // pick last word if it's 3+ letters and not a stopword
        String[] tokens = q.split("\\s+");
        if (tokens.length > 0) {
            String last = tokens[tokens.length - 1];
            if (last.length() >= 3 && !last.matches("(under|below|less|than|cheap|budget|best|show|me|the|and)")) {
                keyword = last;
            }
        }

        // Filter
        for (Product p : allProducts) {
            if (desiredCategory != null) {
                String c = p.category != null ? p.category : "General";
                if (!c.equalsIgnoreCase(desiredCategory)) continue;
            }
            if (maxPrice != null && p.price > maxPrice) continue;
            if (keyword != null) {
                String hay = (p.name + " " + p.description).toLowerCase(Locale.ROOT);
                if (!hay.contains(keyword.toLowerCase(Locale.ROOT))) continue;
            }
            results.add(p);
        }

        // If nothing found, fallback: show 6 best sellers by stock/price heuristics
        if (results.isEmpty()) {
            for (Product p : allProducts) {
                results.add(p);
                if (results.size() >= 6) break;
            }
        }

        return results;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterProducts(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void filterProducts(String query) {
        if (allProducts == null) return;

        if (query.isEmpty()) {
            loadCategorySections();
            return;
        }

        List<Product> filteredList = new ArrayList<>();
        String lowerQuery = query.toLowerCase();

        for (Product product : allProducts) {
            if (product.name.toLowerCase().contains(lowerQuery) ||
                product.description.toLowerCase().contains(lowerQuery)) {
                filteredList.add(product);
            }
        }

        // Show filtered results in a single section
        List<CategorySection> sections = new ArrayList<>();
        if (!filteredList.isEmpty()) {
            sections.add(new CategorySection("Search Results", filteredList));
        }
        categorySectionAdapter.setCategorySections(sections);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh products when returning to this activity
        loadProducts();
        
        // Restart auto-slide
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.postDelayed(sliderRunnable, 3000);
        }
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Stop auto-slide when activity is paused
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up handler
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }
}
