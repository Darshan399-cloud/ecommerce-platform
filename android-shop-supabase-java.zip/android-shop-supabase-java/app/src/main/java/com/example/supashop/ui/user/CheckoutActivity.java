package com.example.supashop.ui.user;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.supashop.R;
import com.example.supashop.data.AuthManager;
import com.example.supashop.models.Order;
import com.example.supashop.models.User;
import com.example.supashop.repository.CartRepository;
import com.example.supashop.repository.OrderRepository;
import com.google.android.material.textfield.TextInputEditText;

public class CheckoutActivity extends AppCompatActivity {
    private TextInputEditText etName, etPhone, etAddress;
    private TextView tvTotal;
    private Button btnPlaceOrder;
    private CartRepository cartRepository;
    private OrderRepository orderRepository;
    private AuthManager authManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        cartRepository = CartRepository.getInstance();
        orderRepository = OrderRepository.getInstance();
        authManager = AuthManager.getInstance();

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etName = findViewById(R.id.et_name);
        etPhone = findViewById(R.id.et_phone);
        etAddress = findViewById(R.id.et_address);
        tvTotal = findViewById(R.id.tv_total);
        btnPlaceOrder = findViewById(R.id.btn_place_order);

        // Pre-fill user data
        User currentUser = authManager.getCurrentUser();
        if (currentUser != null) {
            etName.setText(currentUser.fullName);
        }

        double total = cartRepository.getTotalAmount();
        tvTotal.setText(String.format("₹%.2f", total));

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void placeOrder() {
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        User currentUser = authManager.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        Order order = new Order(
                currentUser.username,
                name,
                currentUser.email,
                address,
                phone,
                cartRepository.getCartItems(),
                cartRepository.getTotalAmount()
        );

        String orderId = orderRepository.createOrder(order);

        new AlertDialog.Builder(this)
                .setTitle("Order Placed Successfully!")
                .setMessage("Order ID: " + orderId + "\n\nYour order has been placed successfully. You will receive a confirmation email shortly.")
                .setPositiveButton("OK", (dialog, which) -> {
                    cartRepository.clearCart();
                    Intent intent = new Intent(CheckoutActivity.this, UserPanelActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }
}
