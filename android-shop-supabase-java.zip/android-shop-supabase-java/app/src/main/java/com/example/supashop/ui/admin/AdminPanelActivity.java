package com.example.supashop.ui.admin;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.example.supashop.R;
import com.example.supashop.data.AuthManager;
import com.example.supashop.models.Banner;
import com.example.supashop.models.CategorySection;
import com.example.supashop.models.Product;
import com.example.supashop.repository.BannerRepository;
import com.example.supashop.repository.OrderRepository;
import com.example.supashop.repository.ProductRepository;
import com.example.supashop.ui.LoginActivity;
import com.example.supashop.ui.user.BannerAdapter;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminPanelActivity extends AppCompatActivity implements ProductAdminAdapter.OnProductActionListener {
    private RecyclerView recyclerCategorySections;
    private CategorySectionAdminAdapter categorySectionAdapter;
    private ProductRepository repository;
    private FloatingActionButton fabAdd;
    private AuthManager authManager;
    private Uri selectedImageUri;
    private ImageView ivProductPreview;
    private ChipGroup chipGroupCategories;
    private List<Product> allProducts;
    private String selectedCategory = "All";
    private TextView tvTotalProducts, tvTotalOrders;
    private Button btnManageBanners, btnViewOrders, btnAddProduct;
    
    // Banner slider
    private ViewPager2 bannerViewPager;
    private BannerAdapter bannerAdapter;
    private BannerRepository bannerRepository;
    private Handler sliderHandler;
    private Runnable sliderRunnable;
    
    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    selectedImageUri = result.getData().getData();
                    if (ivProductPreview != null) {
                        Glide.with(this)
                                .load(selectedImageUri)
                                .centerCrop()
                                .into(ivProductPreview);
                    }
                }
            });
    
    private final ActivityResultLauncher<String> permissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted) {
                    openImagePicker();
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        authManager = AuthManager.getInstance();
        repository = new ProductRepository();
        bannerRepository = BannerRepository.getInstance();
        
        // Setup toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        recyclerCategorySections = findViewById(R.id.recycler_category_sections);
        fabAdd = findViewById(R.id.fab_add_product);
        chipGroupCategories = findViewById(R.id.chip_group_categories);
        bannerViewPager = findViewById(R.id.banner_viewpager);
        
        // Dashboard stats
        tvTotalProducts = findViewById(R.id.tv_total_products);
        tvTotalOrders = findViewById(R.id.tv_total_orders);
        
        // Quick action buttons
        btnManageBanners = findViewById(R.id.btn_manage_banners);
        btnViewOrders = findViewById(R.id.btn_view_orders);
        btnAddProduct = findViewById(R.id.btn_add_product);

        setupBannerSlider();
        setupRecyclerView();
        setupCategoryChips();
        loadProducts();
        setupQuickActions();
        updateDashboardStats();

        fabAdd.setOnClickListener(v -> showAddEditDialog(null));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_admin, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            handleLogout();
            return true;
        } else if (item.getItemId() == R.id.action_switch_panel) {
            switchToUserPanel();
            return true;
        } else if (item.getItemId() == R.id.action_manage_banners) {
            openManageBanners();
            return true;
        } else if (item.getItemId() == R.id.action_view_orders) {
            openOrders();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void switchToUserPanel() {
        Intent intent = new Intent(AdminPanelActivity.this, com.example.supashop.ui.user.UserPanelActivity.class);
        startActivity(intent);
        // Don't call finish() so back button works
    }

    private void openManageBanners() {
        Intent intent = new Intent(AdminPanelActivity.this, ManageBannersActivity.class);
        startActivity(intent);
    }

    private void openOrders() {
        Intent intent = new Intent(AdminPanelActivity.this, OrdersActivity.class);
        startActivity(intent);
    }

    private void handleLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    authManager.logout();
                    Intent intent = new Intent(AdminPanelActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void setupBannerSlider() {
        bannerAdapter = new BannerAdapter();
        bannerViewPager.setAdapter(bannerAdapter);
        
        // Load banners
        List<Banner> banners = bannerRepository.getActiveBanners();
        bannerAdapter.setBanners(banners);
        
        // Setup auto-slide
        sliderHandler = new Handler(Looper.getMainLooper());
        sliderRunnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = bannerViewPager.getCurrentItem();
                int totalItems = bannerAdapter.getItemCount();
                
                if (totalItems > 0) {
                    int nextItem = (currentItem + 1) % totalItems;
                    bannerViewPager.setCurrentItem(nextItem, true);
                }
                
                sliderHandler.postDelayed(this, 3000); // Auto-slide every 3 seconds
            }
        };
        
        // Start auto-slide
        sliderHandler.postDelayed(sliderRunnable, 3000);
    }

    private void setupRecyclerView() {
        categorySectionAdapter = new CategorySectionAdminAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerCategorySections.setLayoutManager(layoutManager);
        recyclerCategorySections.setAdapter(categorySectionAdapter);
        recyclerCategorySections.setNestedScrollingEnabled(false);
    }
    
    private void setupQuickActions() {
        btnManageBanners.setOnClickListener(v -> openManageBanners());
        btnViewOrders.setOnClickListener(v -> openOrders());
        btnAddProduct.setOnClickListener(v -> showAddEditDialog(null));
    }
    
    private void updateDashboardStats() {
        // Update product count
        int productCount = allProducts != null ? allProducts.size() : 0;
        tvTotalProducts.setText(String.valueOf(productCount));
        
        // Update order count from repository
        int orderCount = OrderRepository.getInstance().getAllOrders().size();
        tvTotalOrders.setText(String.valueOf(orderCount));
    }

    private void setupCategoryChips() {
        List<String> categories = com.example.supashop.data.ProductDataManager.getInstance().getAllCategories();
        
        for (String category : categories) {
            Chip chip = new Chip(this);
            chip.setText(category);
            chip.setCheckable(true);
            chip.setChipBackgroundColorResource(android.R.color.white);
            chip.setTextColor(getResources().getColor(android.R.color.black));
            
            if (category.equals("All")) {
                chip.setChecked(true);
            }
            
            chip.setOnClickListener(v -> {
                selectedCategory = category;
                filterByCategory(category);
            });
            
            chipGroupCategories.addView(chip);
        }
    }

    private void loadProducts() {
        allProducts = repository.listProducts();
        loadCategorySections();
        updateDashboardStats();
    }
    
    private void loadCategorySections() {
        // Group products by category
        Map<String, List<Product>> categoryMap = new HashMap<>();
        
        for (Product product : allProducts) {
            String category = product.category != null ? product.category : "General";
            if (!categoryMap.containsKey(category)) {
                categoryMap.put(category, new ArrayList<>());
            }
            categoryMap.get(category).add(product);
        }
        
        // Create category sections
        List<CategorySection> sections = new ArrayList<>();
        for (Map.Entry<String, List<Product>> entry : categoryMap.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                sections.add(new CategorySection(entry.getKey(), entry.getValue()));
            }
        }
        
        categorySectionAdapter.setCategorySections(sections);
    }

    private void filterByCategory(String category) {
        if (category.equals("All")) {
            loadCategorySections();
        } else {
            List<Product> filtered = com.example.supashop.data.ProductDataManager.getInstance().getProductsByCategory(category);
            List<CategorySection> sections = new ArrayList<>();
            if (!filtered.isEmpty()) {
                sections.add(new CategorySection(category, filtered));
            }
            categorySectionAdapter.setCategorySections(sections);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProducts();
        
        // Restart auto-slide
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.postDelayed(sliderRunnable, 3000);
        }
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Stop auto-slide when activity is paused
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up handler
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }

    @Override
    public void onEdit(Product product) {
        showAddEditDialog(product);
    }

    @Override
    public void onDelete(Product product) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Product")
                .setMessage("Are you sure you want to delete " + product.name + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (repository.deleteById(product.id)) {
                        Toast.makeText(this, "Product deleted", Toast.LENGTH_SHORT).show();
                        loadProducts();
                    } else {
                        Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showAddEditDialog(Product existingProduct) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit_product, null);
        
        TextView tvTitle = dialogView.findViewById(R.id.tv_dialog_title);
        ivProductPreview = dialogView.findViewById(R.id.iv_product_preview);
        Button btnSelectImage = dialogView.findViewById(R.id.btn_select_image);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinner_category);
        TextInputEditText etName = dialogView.findViewById(R.id.et_product_name);
        TextInputEditText etDescription = dialogView.findViewById(R.id.et_product_description);
        TextInputEditText etPrice = dialogView.findViewById(R.id.et_product_price);
        TextInputEditText etStock = dialogView.findViewById(R.id.et_product_stock);
        TextInputEditText etImageUrl = dialogView.findViewById(R.id.et_product_image_url);
        Button btnCancel = dialogView.findViewById(R.id.btn_cancel);
        Button btnSave = dialogView.findViewById(R.id.btn_save);

        // Setup category spinner
        String[] categories = {"Electronics", "Fashion", "Home", "Books", "Sports", "Toys", "Ladies Beauty"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        selectedImageUri = null;
        boolean isEdit = existingProduct != null;
        tvTitle.setText(isEdit ? "Edit Product" : "Add Product");

        if (isEdit) {
            etName.setText(existingProduct.name);
            etDescription.setText(existingProduct.description);
            etPrice.setText(String.valueOf(existingProduct.price));
            etStock.setText(String.valueOf(existingProduct.stock));
            etImageUrl.setText(existingProduct.imageUrl);
            
            // Set category
            if (existingProduct.category != null) {
                for (int i = 0; i < categories.length; i++) {
                    if (categories[i].equals(existingProduct.category)) {
                        spinnerCategory.setSelection(i);
                        break;
                    }
                }
            }
            
            // Load existing image
            if (existingProduct.imageUrl != null && !existingProduct.imageUrl.isEmpty()) {
                Glide.with(this)
                        .load(existingProduct.imageUrl)
                        .placeholder(R.drawable.ic_placeholder)
                        .centerCrop()
                        .into(ivProductPreview);
            }
        }
        
        btnSelectImage.setOnClickListener(v -> checkPermissionAndPickImage());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String priceStr = etPrice.getText().toString().trim();
            String stockStr = etStock.getText().toString().trim();
            String imageUrl = etImageUrl.getText().toString().trim();

            if (name.isEmpty() || description.isEmpty() || priceStr.isEmpty() || stockStr.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double price = Double.parseDouble(priceStr);
                int stock = Integer.parseInt(stockStr);

                Product product = new Product();
                if (isEdit) {
                    product.id = existingProduct.id;
                }
                product.name = name;
                product.description = description;
                product.price = price;
                product.stock = stock;
                product.category = spinnerCategory.getSelectedItem().toString();
                
                // Use selected image URI or URL
                if (selectedImageUri != null) {
                    product.imageUrl = selectedImageUri.toString();
                } else if (!imageUrl.isEmpty()) {
                    product.imageUrl = imageUrl;
                } else if (isEdit && existingProduct.imageUrl != null) {
                    product.imageUrl = existingProduct.imageUrl;
                } else {
                    product.imageUrl = "https://via.placeholder.com/150";
                }

                if (isEdit) {
                    if (repository.update(product)) {
                        Toast.makeText(this, "Product updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to update", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    repository.create(product);
                    Toast.makeText(this, "Product added", Toast.LENGTH_SHORT).show();
                }

                loadProducts();
                dialog.dismiss();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid price or stock value", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void checkPermissionAndPickImage() {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission = Manifest.permission.READ_MEDIA_IMAGES;
        } else {
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            openImagePicker();
        } else {
            permissionLauncher.launch(permission);
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        imagePickerLauncher.launch(intent);
    }
}
