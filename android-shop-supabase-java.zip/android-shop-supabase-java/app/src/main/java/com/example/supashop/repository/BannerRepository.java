package com.example.supashop.repository;

import com.example.supashop.models.Banner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BannerRepository {
    private static BannerRepository instance;
    private Map<String, Banner> banners;

    private BannerRepository() {
        banners = new HashMap<>();
        initializeSampleBanners();
    }

    public static synchronized BannerRepository getInstance() {
        if (instance == null) {
            instance = new BannerRepository();
        }
        return instance;
    }

    private void initializeSampleBanners() {
        // Add some sample banners
        addBanner(new Banner(
            UUID.randomUUID().toString(),
            "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800",
            "Summer Sale",
            "Up to 50% OFF on all items"
        ));
        
        addBanner(new Banner(
            UUID.randomUUID().toString(),
            "https://images.unsplash.com/photo-1607082349566-187342175e2f?w=800",
            "New Arrivals",
            "Check out our latest collection"
        ));
        
        addBanner(new Banner(
            UUID.randomUUID().toString(),
            "https://images.unsplash.com/photo-1607083206968-13611e3d76db?w=800",
            "Free Shipping",
            "On orders above $50"
        ));
    }

    public List<Banner> getActiveBanners() {
        List<Banner> activeBanners = new ArrayList<>();
        for (Banner banner : banners.values()) {
            if (banner.isActive) {
                activeBanners.add(banner);
            }
        }
        return activeBanners;
    }

    public List<Banner> getAllBanners() {
        return new ArrayList<>(banners.values());
    }

    public Banner getBannerById(String id) {
        return banners.get(id);
    }

    public void addBanner(Banner banner) {
        if (banner.id == null || banner.id.isEmpty()) {
            banner.id = UUID.randomUUID().toString();
        }
        banners.put(banner.id, banner);
    }

    public void updateBanner(Banner banner) {
        if (banner.id != null && banners.containsKey(banner.id)) {
            banners.put(banner.id, banner);
        }
    }

    public void deleteBanner(String id) {
        banners.remove(id);
    }

    public void toggleBannerStatus(String id) {
        Banner banner = banners.get(id);
        if (banner != null) {
            banner.isActive = !banner.isActive;
        }
    }
}
