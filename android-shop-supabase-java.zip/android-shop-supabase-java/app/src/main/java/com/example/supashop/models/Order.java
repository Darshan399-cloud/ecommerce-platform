package com.example.supashop.models;

import java.util.ArrayList;
import java.util.List;

public class Order {
    public String id;
    public String userId;
    public String userName;
    public String userEmail;
    public String shippingAddress;
    public String phoneNumber;
    public List<CartItem> items;
    public double totalAmount;
    public String status; // "Pending", "Processing", "Shipped", "Delivered", "Cancelled"
    public long orderDate;

    public Order() {
        this.items = new ArrayList<>();
        this.status = "Pending";
        this.orderDate = System.currentTimeMillis();
    }

    public Order(String userId, String userName, String userEmail, String shippingAddress, String phoneNumber, List<CartItem> items, double totalAmount) {
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.shippingAddress = shippingAddress;
        this.phoneNumber = phoneNumber;
        this.items = new ArrayList<>(items);
        this.totalAmount = totalAmount;
        this.status = "Pending";
        this.orderDate = System.currentTimeMillis();
    }
}
