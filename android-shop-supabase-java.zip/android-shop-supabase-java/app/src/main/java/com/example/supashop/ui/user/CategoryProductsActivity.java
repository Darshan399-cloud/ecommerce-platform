package com.example.supashop.ui.user;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supashop.R;
import com.example.supashop.models.Product;
import com.example.supashop.repository.ProductRepository;

import java.util.ArrayList;
import java.util.List;

public class CategoryProductsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProductGridAdapter adapter;
    private ProductRepository repository;
    private TextView tvCategoryTitle;
    private String categoryName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_products);

        // Get category name from intent
        categoryName = getIntent().getStringExtra("CATEGORY_NAME");
        if (categoryName == null) {
            categoryName = "Products";
        }

        // Setup toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(categoryName);
        }

        tvCategoryTitle = findViewById(R.id.tv_category_title);
        recyclerView = findViewById(R.id.recycler_products);
        
        tvCategoryTitle.setText(categoryName + " Products");
        
        repository = new ProductRepository();
        
        setupRecyclerView();
        loadProducts();
    }

    private void setupRecyclerView() {
        adapter = new ProductGridAdapter();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(adapter);
    }

    private void loadProducts() {
        List<Product> allProducts = repository.listProducts();
        List<Product> categoryProducts = new ArrayList<>();
        
        for (Product product : allProducts) {
            if (product.category != null && product.category.equals(categoryName)) {
                categoryProducts.add(product);
            }
        }
        
        adapter.setProducts(categoryProducts);
        
        android.util.Log.d("CategoryProducts", "Loaded " + categoryProducts.size() + " products for " + categoryName);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
