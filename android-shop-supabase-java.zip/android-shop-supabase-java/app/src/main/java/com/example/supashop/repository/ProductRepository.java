package com.example.supashop.repository;

import com.example.supashop.data.ProductDataManager;
import com.example.supashop.models.Product;

import java.util.List;

public class ProductRepository {
    private final ProductDataManager dataManager = ProductDataManager.getInstance();

    public List<Product> listProducts() {
        return dataManager.getAllProducts();
    }

    public void create(Product p) {
        dataManager.addProduct(p);
    }

    public boolean update(Product p) {
        return dataManager.updateProduct(p);
    }

    public boolean deleteById(int id) {
        return dataManager.deleteProduct(id);
    }

    public Product getById(int id) {
        return dataManager.getProductById(id);
    }
}
