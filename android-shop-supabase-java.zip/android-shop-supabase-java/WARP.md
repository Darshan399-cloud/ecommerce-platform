# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project overview
Android app (Java) with admin and user panels backed by Supabase PostgREST. Networking via Retrofit/OkHttp; simple repository layer; Activities drive navigation.

## Commands
Note: This repo does not include the Gradle Wrapper. Use an installed Gradle (or Android Studio’s Gradle) and run from the repo root.

- Build debug APK: `gradle :app:assembleDebug`
- Install on device/emulator: `gradle :app:installDebug`
- Clean: `gradle clean`
- Android Lint (debug): `gradle :app:lintDebug` (HTML report under `app/build/reports/lint/`)
- All unit tests (when added): `gradle :app:testDebugUnitTest`
- Single unit test (when added): `gradle :app:testDebugUnitTest --tests com.example.supashop.SomeTestClass`
- Instrumented tests (when added, device/emulator required): `gradle :app:connectedAndroidTest`
- Single instrumented test class: `gradle :app:connectedAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.example.supashop.SomeInstrumentedTest`

## Required setup
Supabase credentials are read from BuildConfig fields defined in `app/build.gradle`:
- `BuildConfig.SUPABASE_URL`
- `BuildConfig.SUPABASE_ANON_KEY`

Per README, set these to your values before running. `SupabaseClient` derives the API base as `${SUPABASE_URL}/rest/v1/` and will use either an auth token (if set) or the anon key for the `Authorization` header.

## Architecture (big picture)
- UI layer (`app/src/main/java/com/example/supashop/ui/...`)
  - `MainActivity` is the launcher and routes to `LoginActivity`, `AdminPanelActivity`, or `UserPanelActivity` (auth currently stubbed).
- Data access
  - `repository/ProductRepository` exposes blocking methods (Retrofit `execute()`) for listing/creating/deleting `Product`s.
  - `data/supabase/ApiService` defines PostgREST endpoints for the `products` table.
  - `data/supabase/SupabaseClient` builds a Retrofit singleton with OkHttp interceptors for `apikey` and `Authorization` headers and BASIC HTTP logging.
- Model
  - `models/Product` maps Supabase columns via Gson annotations.

Flow: UI Activity → `ProductRepository` → `ApiService` (Retrofit) → Supabase PostgREST.

Notes:
- Auth is stubbed; after implementing Supabase GoTrue login, call `SupabaseClient.setAuthToken(token)` to switch to user-scoped bearer tokens.
- Repository methods are synchronous; call them off the main thread in production.

## Important from README
- Requirements: Android Studio (Giraffe+), Android SDK 34, JDK 17.
- Minimal DB: `products` table with fields described in README; enable RLS and policies as needed.
- Module layout: UI, data/supabase, repository, models (see paths above).
